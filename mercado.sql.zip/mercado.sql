--
-- Database: `mercado`
--
CREATE DATABASE IF NOT EXISTS `mercado` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `mercado`;

-- --------------------------------------------------------

--
-- Table structure for table `categorias`
--

CREATE TABLE `categorias` (
  `id` int(11) NOT NULL,
  `nome` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `data_hora_cadastro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `categorias`
--

INSERT INTO `categorias` (`id`, `nome`, `data_hora_cadastro`, `status`) VALUES
(1, 'Alimentos', '2016-07-26 17:44:08', 1),
(2, 'Bebidas', '2016-07-26 17:44:16', 1),
(3, 'Outros', '2016-07-26 17:44:18', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cidades`
--

CREATE TABLE `cidades` (
  `id` int(11) NOT NULL,
  `nome` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `estado_id` int(11) NOT NULL,
  `data_hora_cadastro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `cidades`
--

INSERT INTO `cidades` (`id`, `nome`, `estado_id`, `data_hora_cadastro`, `status`) VALUES
(1, 'Curitiba', 2, '2016-07-21 20:07:52', 1),
(2, 'Florianópolis', 1, '2016-07-21 20:08:01', 1),
(3, 'Tijucas', 1, '2016-07-21 20:08:06', 1),
(4, 'Sssss', 1, '2016-07-26 19:49:00', 1),
(5, 'Ssssssssss', 2, '2016-07-26 19:51:03', 1);

-- --------------------------------------------------------

--
-- Table structure for table `clientes`
--

CREATE TABLE `clientes` (
  `id` int(11) NOT NULL,
  `nome` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `data_nascimento` date NOT NULL,
  `telefone` varchar(22) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `cidade_id` int(11) NOT NULL,
  `data_cadastro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `clientes`
--

INSERT INTO `clientes` (`id`, `nome`, `data_nascimento`, `telefone`, `email`, `cidade_id`, `data_cadastro`, `status`) VALUES
(1, 'Renato Silva', '1990-04-20', '(48) 9963-6294', 'renato@email.com', 2, '2016-07-26 18:19:30', 1);

-- --------------------------------------------------------

--
-- Table structure for table `estados`
--

CREATE TABLE `estados` (
  `id` int(11) NOT NULL,
  `nome` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `sigla` char(2) COLLATE utf8_unicode_ci NOT NULL,
  `data_hora_cadastro` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `estados`
--

INSERT INTO `estados` (`id`, `nome`, `sigla`, `data_hora_cadastro`, `status`) VALUES
(1, 'Santa Catarina', 'sc', '2016-07-21 17:07:36', 1),
(2, 'Paraná', 'pr', '2016-07-21 17:07:43', 1);

-- --------------------------------------------------------

--
-- Table structure for table `filiais`
--

CREATE TABLE `filiais` (
  `id_filiais` int(11) NOT NULL,
  `nomeFantasia` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `cpf` varchar(11) COLLATE utf8_unicode_ci NOT NULL,
  `telefone` varchar(22) COLLATE utf8_unicode_ci NOT NULL,
  `valor` float NOT NULL,
  `dataIni` date NOT NULL,
  `email` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `cidade_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `funcionarios`
--

CREATE TABLE `funcionarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `data_admissao` date NOT NULL,
  `telefone` varchar(22) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `cidade_id` int(11) NOT NULL,
  `data_hora_cadastro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '1',
  `senha` varchar(80) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `funcionarios`
--

INSERT INTO `funcionarios` (`id`, `nome`, `data_admissao`, `telefone`, `email`, `cidade_id`, `data_hora_cadastro`, `status`, `senha`) VALUES
(1, 'João Pedro', '2016-07-21', '48 99636294', 'joao@email.com', 2, '2016-07-21 20:09:27', 1, '202cb962ac59075b964b07152d234b70'),
(2, 'Ricardo Eletro', '2016-06-26', '48 9963 6294', 'ricardo@email.com', 3, '2016-07-26 18:30:06', 1, '202cb962ac59075b964b07152d234b70'),
(3, 'Ricardo Eletro', '2016-06-26', '(48) 9963-6294', 'admin@email.com', 2, '2016-07-26 18:31:00', 1, '202cb962ac59075b964b07152d234b70');

-- --------------------------------------------------------

--
-- Table structure for table `itens_venda`
--

CREATE TABLE `itens_venda` (
  `id` int(11) NOT NULL,
  `venda_id` int(11) NOT NULL,
  `produto_id` int(11) NOT NULL,
  `quantidade` int(11) NOT NULL,
  `valor` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `produtos`
--

CREATE TABLE `produtos` (
  `id` int(11) NOT NULL,
  `nome` varchar(45) COLLATE utf8_unicode_ci NOT NULL,
  `valor` float NOT NULL,
  `imagem` text COLLATE utf8_unicode_ci NOT NULL,
  `categoria_id` int(11) NOT NULL,
  `data_hora_cadastro` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `produtos`
--

INSERT INTO `produtos` (`id`, `nome`, `valor`, `imagem`, `categoria_id`, `data_hora_cadastro`, `status`) VALUES
(1, 'Carvão para churrasco', 6.7, 'imagens/1469502000carvao-vegetal.jpg', 3, '2016-07-26 18:07:39', 1),
(2, 'Suco Macrovita', 3.5, 'imagens/1469502000suco-01.jpg', 2, '2016-07-26 18:08:01', 1),
(3, 'Feijão Caldão 1kg', 4.75, 'imagens/146950200085063dda8c1e07130714586ac06a9eae-650-400.jpg', 1, '2016-07-26 18:08:24', 1),
(4, 'Feijão Caldão - Carioca 1kg', 5, 'imagens/1469502000carioca_g.jpg', 1, '2016-07-26 18:08:50', 1),
(5, 'Arroz Tio João', 3.77, 'imagens/1469502000arroz.jpg', 1, '2016-07-26 18:09:13', 1),
(6, 'Coca-cola 2L', 4, 'imagens/1469502000coca.png', 2, '2016-07-26 18:10:04', 1),
(7, 'Aaaaaa', 3755.55, '', 1, '2016-07-26 18:59:37', 1);

-- --------------------------------------------------------

--
-- Table structure for table `vendas`
--

CREATE TABLE `vendas` (
  `id` int(11) NOT NULL,
  `data_venda` date NOT NULL,
  `hora_venda` time NOT NULL,
  `valor_total` float NOT NULL,
  `cliente_id` int(11) NOT NULL,
  `funcionario_id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `vendas`
--

INSERT INTO `vendas` (`id`, `data_venda`, `hora_venda`, `valor_total`, `cliente_id`, `funcionario_id`, `status`) VALUES
(1, '2016-07-26', '16:58:16', 0, 1, 1, 1),
(2, '2016-07-26', '17:04:17', 0, 1, 1, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categorias`
--
ALTER TABLE `categorias`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `cidades`
--
ALTER TABLE `cidades`
  ADD PRIMARY KEY (`id`),
  ADD KEY `estado_id` (`estado_id`);

--
-- Indexes for table `clientes`
--
ALTER TABLE `clientes`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cidade_id` (`cidade_id`);

--
-- Indexes for table `estados`
--
ALTER TABLE `estados`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `filiais`
--
ALTER TABLE `filiais`
  ADD PRIMARY KEY (`id_filiais`),
  ADD KEY `cidade_id` (`cidade_id`);

--
-- Indexes for table `funcionarios`
--
ALTER TABLE `funcionarios`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cidade_id` (`cidade_id`);

--
-- Indexes for table `itens_venda`
--
ALTER TABLE `itens_venda`
  ADD PRIMARY KEY (`id`),
  ADD KEY `venda_id` (`venda_id`),
  ADD KEY `produto_id` (`produto_id`);

--
-- Indexes for table `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categoria_id` (`categoria_id`);

--
-- Indexes for table `vendas`
--
ALTER TABLE `vendas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `cliente_id` (`cliente_id`),
  ADD KEY `funcionario_id` (`funcionario_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categorias`
--
ALTER TABLE `categorias`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `cidades`
--
ALTER TABLE `cidades`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `clientes`
--
ALTER TABLE `clientes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `estados`
--
ALTER TABLE `estados`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `filiais`
--
ALTER TABLE `filiais`
  MODIFY `id_filiais` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `funcionarios`
--
ALTER TABLE `funcionarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `itens_venda`
--
ALTER TABLE `itens_venda`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `produtos`
--
ALTER TABLE `produtos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `vendas`
--
ALTER TABLE `vendas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `cidades`
--
ALTER TABLE `cidades`
  ADD CONSTRAINT `cidades_ibfk_1` FOREIGN KEY (`estado_id`) REFERENCES `estados` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `itens_venda`
--
ALTER TABLE `itens_venda`
  ADD CONSTRAINT `itens_venda_ibfk_1` FOREIGN KEY (`venda_id`) REFERENCES `vendas` (`id`),
  ADD CONSTRAINT `itens_venda_ibfk_2` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`);

--
-- Constraints for table `produtos`
--
ALTER TABLE `produtos`
  ADD CONSTRAINT `produtos_ibfk_1` FOREIGN KEY (`categoria_id`) REFERENCES `categorias` (`id`);

--
-- Constraints for table `vendas`
--
ALTER TABLE `vendas`
  ADD CONSTRAINT `vendas_ibfk_1` FOREIGN KEY (`cliente_id`) REFERENCES `clientes` (`id`),
  ADD CONSTRAINT `vendas_ibfk_2` FOREIGN KEY (`funcionario_id`) REFERENCES `funcionarios` (`id`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
